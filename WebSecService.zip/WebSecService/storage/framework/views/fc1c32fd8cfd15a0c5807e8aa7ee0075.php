

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2 class="text-center">Supermarket Bill</h2>

        <table class="table table-bordered table-striped mt-3">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Price (per unit)</th>
                    <th>Total Price</th>
                </tr>
            </thead>
            <tbody>
                <?php $grandTotal = 0; ?>

                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total = $item['quantity'] * $item['price'];
                        $grandTotal += $total;
                    ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($item['name']); ?></td>
                        <td><?php echo e($item['quantity']); ?></td>
                        <td>$<?php echo e(number_format($item['price'], 2)); ?></td>
                        <td>$<?php echo e(number_format($total, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr class="table-success">
                    <td colspan="4" class="text-start"><strong>Grand Total:</strong></td>
                    <td><strong>$<?php echo e(number_format($grandTotal, 2)); ?></strong></td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSecService\WebSecService\resources\views/bill.blade.php ENDPATH**/ ?>