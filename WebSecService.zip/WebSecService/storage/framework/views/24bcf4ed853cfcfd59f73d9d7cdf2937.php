
<?php $__env->startSection('title', 'Users List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">Users List</div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('users.index')); ?>">
                <div class="input-group mb-3">
                    <input type="text" name="search" class="form-control" placeholder="Search users" value="<?php echo e(request()->search); ?>">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>
            </form>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success mb-3">Add User</a>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Admin</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->admin ? 'Yes' : 'No'); ?></td>
                            <td>
                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning">Edit</a>
                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($users->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSecService\WebSecService\resources\views/users/index.blade.php ENDPATH**/ ?>