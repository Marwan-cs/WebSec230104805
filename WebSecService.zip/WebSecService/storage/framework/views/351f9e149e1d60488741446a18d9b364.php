
<?php $__env->startSection('title', 'Edit User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">Edit User</div>
        <div class="card-body">
            <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group mb-2">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required>
                </div>
                <div class="form-group mb-2">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required>
                </div>
                <div class="form-group mb-2">
                    <label for="password" class="form-label">Password (leave blank to keep current password):</label>
                    <input type="password" class="form-control" name="password">
                </div>
                <div class="form-group mb-2">
                    <label for="password_confirmation" class="form-label">Confirm Password:</label>
                    <input type="password" class="form-control" name="password_confirmation">
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_users')): ?>
                <div class="col-12 mb-2">
                    <label for="model" class="form-label">Roles:</label>
                    <select multiple class="form-select" name="roles[]">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value='<?php echo e($role->name); ?>' <?php echo e($role->taken?'selected':''); ?>>
                                <?php echo e($role->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-12 mb-2">
                    <label for="model" class="form-label">Direct Permissions:</label>
                    <select multiple class="form-select" name="permissions[]">
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value='<?php echo e($permission->name); ?>' <?php echo e($permission->taken?'selected':''); ?>>
                                <?php echo e($permission->display_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="form-group mb-2">
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>

    <div class="d-flex justify-content-center">
        <div class="row m-4 col-sm-8">
            <form action="<?php echo e(route('users_save', $user->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong> <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-2">
                    <div class="col-12">
                        <label for="code" class="form-label">Name:</label>
                        <input type="text" class="form-control" placeholder="Name" name="name" required value="<?php echo e($user->name); ?>">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSecService\WebSecService\resources\views/users/edit.blade.php ENDPATH**/ ?>