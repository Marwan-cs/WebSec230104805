<?php $__env->startSection('title', 'Prime Numbers'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        function isPrime($number) {
            if ($number < 2) return false;
            for ($i = 2; $i * $i <= $number; $i++) {
                if ($number % $i == 0) return false;
            }
            return true;
        }
    ?>

    <div class="card m-4">
        <div class="card-header text-center fw-bold">Prime Numbers</div>
        <div class="card-body text-center">
            <?php $__currentLoopData = range(1, 100); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isPrime($i)): ?>
                    <span class="badge bg-primary m-1"><?php echo e($i); ?></span>
                <?php else: ?>
                    <span class="badge bg-secondary"><?php echo e($i); ?></span>    
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .badge { font-size: 1.2rem; margin: 2px; }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSecService\WebSecService\resources\views/prime.blade.php ENDPATH**/ ?>