<nav class="navbar navbar-expand-sm bg-light">
    <div class="container-fluid">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('even')); ?>">Even Numbers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('prime')); ?>">Prime Numbers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('multable')); ?>">Multiplication Table</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('bill')); ?>">Mini Test</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('products.list')); ?>">Products List</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">User List</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('grades')); ?>">Grades</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('tasks.index')); ?>">Tasks</a>
            </li>
        </ul>
        <ul class="navbar-nav">
            <?php if(auth()->guard()->check()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('profile')); ?>"><?php echo e(auth()->user()->name); ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('do_logout')); ?>">Logout</a>
            </li>
            <?php else: ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\WebSecService\WebSecService\resources\views/layouts/menu.blade.php ENDPATH**/ ?>